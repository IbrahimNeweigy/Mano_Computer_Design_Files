`timescale 1ns/1ps


module Memory(
    input         clk,
    input         we,
    input  [3:0]  addr,
    input  [7:0]  data_in,
    output [7:0]  data_out
);
    reg [7:0] mem [15:0];
    
    initial begin
        $readmemh("memory_data.txt", mem);
        $display(mem);
    end


    always @(posedge clk) begin
        if (we)
            mem[addr] <= data_in;
    end

    assign data_out = mem[addr];
endmodule


module ALU(
    input  [7:0] AC,
    input  [7:0] DR,
    input  [2:0] op,      
    output reg [7:0] result,
    output reg       E_out
);
    always @(*) begin
        case(op)
            3'b000: begin               // AND
                result = AC & DR;
                E_out  = 1'b0;
            end
            3'b001: begin               // ADD
                {E_out, result} = AC + DR;
            end
            3'b010: begin               // LDA
                result = DR;
                E_out  = 1'b0;
            end
            3'b011: begin               // CLA (used in register-ref)
                result = 8'b0;
                E_out  = 1'b0;
            end
            default: begin
                result = 8'b0;
                E_out  = 1'b0;
            end
        endcase
    end
endmodule

module ControlUnit(
    input         clk,
    input         reset,
    input  [7:0]  IR,
    output reg [3:0] SC,
    output reg       halt,
    output reg [2:0] alu_op,
    output reg       mem_we,
    output reg       update_pc,
    output reg       update_ar,
    output reg       load_DR,
    output reg       load_AC
);
    // State counter
    always @(posedge clk or posedge reset) begin
        if (reset) SC <= 4'd0;
        else        SC <= SC + 4'd1;
    end


    always @(*) begin
        // defaults
        halt      = 1'b0;
        alu_op    = 3'b000;
        mem_we    = 1'b0;
        update_pc = 1'b0;
        update_ar = 1'b0;
        load_DR   = 1'b0;
        load_AC   = 1'b0;

case (SC)
          4'd0: update_ar = 1'b1;  // AR ? PC
          4'd1: update_pc = 1'b1;  // PC++
          4'd2: begin              // Decode
            update_ar = 1'b1;      // AR ? IR[3:0]
            alu_op    = IR[6:4];
          end
          4'd3: begin              // T3: DR-fetch or reg-ref
            case (IR[6:4])
              3'b000, 3'b001, 3'b010: load_DR = 1'b1; // AND, ADD, LDA
              3'b011: mem_we    = 1'b1;               // STA
              3'b111: begin                          
                case (IR[3:0])
                  4'b1000: begin                     
                    load_AC = 1'b1;
                    alu_op  = 3'b011;
                  end
                  4'b0011: begin                     
                    load_AC = 1'b1;
                    alu_op  = 3'b010;              
                  end
                  4'b0111: halt = 1'b1;            
                  default:  ;
                endcase
              end
              default: ;
            endcase
          end
          4'd4: begin             
case (IR[6:4])
              3'b000, 3'b001, 3'b010: begin
                load_AC = 1'b1;
                alu_op  = IR[6:4];  // AND, ADD, LDA
              end
              default: ;
            endcase
          end
          default: ;
        endcase
    end
endmodule



module IOUnit(
    input  [7:0] INPR,
    input  [7:0] AC,
    input        io_sel,   // 1=INP, 0=OUT
    output reg [7:0] OUTR
);
    always @(*) begin
        if (io_sel)
            OUTR = INPR;
        else
            OUTR = AC;
    end
endmodule



module BasicComputer_Top(
    input         clk,
    input         reset,
    input  [7:0]  INPR,
    output [7:0]  OUTR,
    output [7:0]  AC,
    output [7:0]  IR,
    output [3:0]  PC,
    output [3:0]  AR,
    output        halt
);
    // Internal regs
    reg [7:0] reg_IR, reg_DR, reg_AC;
    reg [3:0] reg_PC, reg_AR;


    wire [7:0] mem_data_out, alu_result;
    wire       mem_we, update_pc, update_ar, load_DR, load_AC, ctrl_halt;
    wire [2:0] alu_op;
    wire [3:0] SC;
    wire       E_out;


    Memory      mem_inst   (.clk(clk),      .we(mem_we),
                            .addr(reg_AR),  .data_in(reg_AC),
                            .data_out(mem_data_out));

    ALU         alu_inst   (.AC(reg_AC),    .DR(reg_DR),
                            .op(alu_op),    .result(alu_result),
                            .E_out(E_out));

    ControlUnit ctrl_inst  (.clk(clk),      .reset(reset),
                            .IR(reg_IR),    .SC(SC),
                            .halt(ctrl_halt),
                            .alu_op(alu_op),.mem_we(mem_we),
                            .update_pc(update_pc),
                            .update_ar(update_ar),
                            .load_DR(load_DR),.load_AC(load_AC));

    IOUnit      io_inst    (.INPR(INPR),    .AC(reg_AC),
                            .io_sel(1'b0),  .OUTR(OUTR));


    always @(posedge clk or posedge reset) begin
        if (reset) begin
            reg_PC <= 4'd0; reg_IR <= 8'd0;
            reg_DR <= 8'd0; reg_AC <= 8'd0;
            reg_AR <= 4'd0;
        end else begin
            case (SC)
              4'd0: if (update_ar) reg_AR <= reg_PC;
              4'd1: if (update_pc) begin reg_IR <= mem_data_out; reg_PC <= reg_PC + 1; end
              4'd2: if (update_ar) reg_AR <= reg_IR[3:0];
              4'd3: begin
                        if (load_DR)          reg_DR <= mem_data_out;
                        else if (reg_IR==8'hF8) reg_AC <= INPR;                  // INP
                        else if (reg_IR[6:4]==3'b111 && reg_IR[3:0]==4'b0011)     // INC
                                                 reg_AC <= reg_AC + 1;
                     end
              4'd4: if (load_AC) reg_AC <= alu_result;
              default: ;
            endcase
        end
    end

    assign AC   = reg_AC;
    assign IR   = reg_IR;
    assign PC   = reg_PC;
    assign AR   = reg_AR;
    assign halt = ctrl_halt;

    always @(posedge clk) begin
        $display("Time=%t SC=%d IR=%h PC=%d AR=%d AC=%h alu_op=%b DR=%h we=%b ldAC=%b halt=%b",
            $time, SC, reg_IR, reg_PC, reg_AR, reg_AC, alu_op, reg_DR, mem_we, load_AC, ctrl_halt);
    end
endmodule
